import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MusicApp());

class MusicApp extends StatelessWidget {
  const MusicApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Music player',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF7C5CD6),
          scaffoldBackgroundColor: Colors.white,
        ),
        home: const Home(),
      );
}

class Song {
  final int id;
  final String title, artist, album;
  final String? uri;
  Song(this.id, this.title, this.artist, this.album, [this.uri]);
  factory Song.from(Map m) {
    String clean(dynamic v, String d) {
      final s = (v ?? '').toString();
      return (s.isEmpty || s == '<unknown>') ? d : s;
    }
    return Song(m['id'] as int, clean(m['title'], 'Unknown title'),
        clean(m['artist'], 'Unknown artist'), clean(m['album'], 'Unknown album'));
  }
  Color get color =>
      HSLColor.fromAHSL(1, (id * 47 % 360).toDouble(), .35, .42).toColor();
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  static const ch = MethodChannel('music_player/media');
  final player = AudioPlayer();
  final rnd = Random();
  List<Song> all = [];
  String q = '';
  int tab = 0;
  bool asc = true, shuffle = false, loading = true, denied = false;
  Song? cur;

  @override
  void initState() {
    super.initState();
    player.processingStateStream.listen((s) {
      if (s == ProcessingState.completed) next();
    });
    player.playerStateStream.listen((_) {
      if (mounted) setState(() {});
    });
    ch.setMethodCallHandler((c) async {
      if (c.method == 'newIntent') openUri(c.arguments as String?);
    });
    load();
  }

  void openUri(String? u) {
    if (u == null) return;
    final seg = Uri.parse(u).pathSegments;
    final last = seg.isEmpty ? 'Audio' : seg.last;
    final id = int.tryParse(last);
    for (final s in all) {
      if (s.id == id) {
        play(s);
        return;
      }
    }
    play(Song(-1, Uri.decodeComponent(last), 'Unknown artist', 'Unknown album', u));
  }

  Future<void> promptDefault() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('skipDefault') ?? false) return;
      final sid = all.isNotEmpty ? all.first.id : 0;
      final d = await ch.invokeMethod<bool>('isDefault', sid) ?? true;
      if (d || !mounted) return;
      final go = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Set as default music player'),
          content: const Text(
              'Make Music player your default app for opening audio files? Choose "Music player" and tap "Always".'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(c, false), child: const Text('Skip')),
            FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Text('Set default')),
          ],
        ),
      );
      if (go == true) {
        await ch.invokeMethod('openPicker', sid);
      } else {
        await prefs.setBool('skipDefault', true);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      denied = false;
    });
    final r = await [Permission.audio, Permission.storage].request();
    if (!r.values.any((s) => s.isGranted)) {
      setState(() {
        loading = false;
        denied = true;
      });
      return;
    }
    try {
      final res = await ch.invokeMethod<List<dynamic>>('getSongs');
      all = (res ?? []).map((e) => Song.from(Map.from(e as Map))).toList();
    } catch (_) {}
    if (mounted) setState(() => loading = false);
    try {
      final u = await ch.invokeMethod<String>('getIntentUri');
      openUri(u);
    } catch (_) {}
    if (mounted) await promptDefault();
  }

  List<Song> get shown {
    final l = all
        .where((s) => ('${s.title} ${s.artist} ${s.album}')
            .toLowerCase()
            .contains(q.toLowerCase()))
        .toList();
    l.sort((a, b) => asc
        ? a.title.toLowerCase().compareTo(b.title.toLowerCase())
        : b.title.toLowerCase().compareTo(a.title.toLowerCase()));
    return l;
  }

  Future<void> play(Song s) async {
    setState(() => cur = s);
    try {
      await player.setAudioSource(AudioSource.uri(
          Uri.parse(s.uri ?? 'content://media/external/audio/media/${s.id}')));
      player.play();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Cannot play this file')));
      }
    }
  }

  void next() {
    final l = shown;
    if (l.isEmpty) return;
    final i = cur == null ? -1 : l.indexWhere((s) => s.id == cur!.id);
    play(shuffle ? l[rnd.nextInt(l.length)] : l[(i + 1) % l.length]);
  }

  void toggle() {
    player.playing ? player.pause() : player.play();
  }

  Widget tile(String t, IconData ic, List<Color> c) => Expanded(
        child: Container(
          height: 86,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
                colors: c, begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(ic, color: Colors.white, size: 28),
              Text(t,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500)),
            ],
          ),
        ),
      );

  Widget promo(String t, Color c, {bool round = false}) => Expanded(
        child: Column(children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
                color: c,
                borderRadius: BorderRadius.circular(round ? 25 : 13)),
          ),
          const SizedBox(height: 5),
          Text(t, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12)),
        ]),
      );

  Widget header() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          IconButton(
              onPressed: () {}, icon: const Icon(Icons.tune_rounded, size: 30)),
          const SizedBox(width: 4),
          Expanded(
            child: TextField(
              onChanged: (v) => setState(() => q = v),
              decoration: InputDecoration(
                hintText: 'Search songs, playlists, and artists',
                hintStyle: const TextStyle(color: Colors.black45, fontSize: 15),
                prefixIcon: const Icon(Icons.search, color: Colors.black45),
                suffixIcon: const Icon(Icons.mic_none, color: Colors.black54),
                filled: true,
                fillColor: const Color(0xFFF1F1F4),
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 18),
        Row(children: [
          tile('Favorites', Icons.favorite, const [Color(0xFF6E2A43), Color(0xFFB0476A)]),
          const SizedBox(width: 12),
          tile('Playlists', Icons.album, const [Color(0xFF1C3347), Color(0xFF4D7F94)]),
          const SizedBox(width: 12),
          tile('Recent', Icons.schedule, const [Color(0xFF2A2457), Color(0xFF5A4CA8)]),
        ]),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
          decoration: BoxDecoration(
              color: const Color(0xFFF0E9FB), borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 12),
              child: Text('Promotion',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
            ),
            Row(children: [
              promo('Bitunix Pro: B…', const Color(0xFFB6F23A)),
              promo('Music for Mo…', const Color(0xFFFDC82B), round: true),
              promo('Color Block: …', const Color(0xFF3B7A3B)),
              promo('Eyecon Caller…', const Color(0xFF1565E8)),
            ]),
          ]),
        ),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          for (final e in ['Songs', 'Videos', 'Artists', 'Albums'].asMap().entries)
            GestureDetector(
              onTap: () => setState(() => tab = e.key),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                    color: tab == e.key ? Colors.black : Colors.transparent,
                    borderRadius: BorderRadius.circular(22)),
                child: Text(e.value,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: tab == e.key ? FontWeight.w500 : FontWeight.w400,
                        color: tab == e.key ? Colors.white : Colors.black54)),
              ),
            ),
        ]),
        const SizedBox(height: 12),
        if (tab == 0)
          Row(children: [
            GestureDetector(
              onTap: () {
                final l = shown;
                if (l.isNotEmpty) {
                  shuffle = true;
                  play(l[rnd.nextInt(l.length)]);
                }
              },
              child: const CircleAvatar(
                  radius: 23,
                  backgroundColor: Colors.black,
                  child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30)),
            ),
            const SizedBox(width: 12),
            const Expanded(
                child: Text('Shuffle playback',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500))),
            IconButton(
                onPressed: () => setState(() => asc = !asc),
                icon: const Icon(Icons.swap_vert_rounded, size: 30)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.playlist_add_check, size: 30)),
          ]),
      ]);

  Widget songRow(Song s) {
    final on = cur?.id == s.id;
    return InkWell(
      onTap: () {
        shuffle = false;
        play(s);
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
                color: s.color, borderRadius: BorderRadius.circular(7)),
            child: const Icon(Icons.music_note, color: Colors.white70),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 17.5,
                      color: on ? const Color(0xFF7C5CD6) : Colors.black)),
              const SizedBox(height: 5),
              Row(children: [
                const Icon(Icons.smartphone_outlined, size: 18, color: Colors.black38),
                const SizedBox(width: 6),
                Expanded(
                  child: Text('${s.artist} | ${s.album}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 14.5, color: Colors.black45)),
                ),
              ]),
            ]),
          ),
          const Icon(Icons.more_vert, color: Colors.black45),
        ]),
      ),
    );
  }

  Widget groups(bool byArtist) {
    final m = <String, int>{};
    for (final s in all) {
      final k = byArtist ? s.artist : s.album;
      m[k] = (m[k] ?? 0) + 1;
    }
    final keys = m.keys.toList()..sort();
    return Column(children: [
      for (final k in keys)
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(
              backgroundColor: const Color(0xFFF0E9FB),
              child: Icon(byArtist ? Icons.person : Icons.album,
                  color: const Color(0xFF7C5CD6))),
          title: Text(k, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${m[k]} songs'),
          onTap: () => setState(() {
            q = k;
            tab = 0;
          }),
        ),
    ]);
  }

  Widget body() {
    if (loading) {
      return const Padding(
          padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()));
    }
    if (denied) {
      return Padding(
        padding: const EdgeInsets.all(30),
        child: Column(children: [
          const Text('Allow audio access to see the songs on your phone.',
              textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton(onPressed: openAppSettings, child: const Text('Open settings')),
          TextButton(onPressed: load, child: const Text('Try again')),
        ]),
      );
    }
    if (tab == 1) {
      return const Padding(
          padding: EdgeInsets.all(40), child: Center(child: Text('No videos')));
    }
    if (tab == 2) return groups(true);
    if (tab == 3) return groups(false);
    final l = shown;
    if (l.isEmpty) {
      return const Padding(
          padding: EdgeInsets.all(40), child: Center(child: Text('No songs found')));
    }
    return Column(children: [for (final s in l) songRow(s)]);
  }

  Widget mini() {
    final s = cur!;
    return Container(
      height: 62,
      decoration: BoxDecoration(
          color: const Color(0xFFD9D2E9), borderRadius: BorderRadius.circular(32)),
      clipBehavior: Clip.antiAlias,
      child: Stack(children: [
        Row(children: [
          const SizedBox(width: 8),
          CircleAvatar(
              radius: 23,
              backgroundColor: s.color,
              child: const Icon(Icons.music_note, color: Colors.white70)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
              Text(s.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, color: Colors.black54)),
            ]),
          ),
          GestureDetector(
            onTap: toggle,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                  shape: BoxShape.circle, border: Border.all(width: 2, color: Colors.black87)),
              child: Icon(player.playing ? Icons.pause : Icons.play_arrow, size: 26),
            ),
          ),
          IconButton(onPressed: next, icon: const Icon(Icons.skip_next, size: 28)),
          const SizedBox(width: 4),
        ]),
        Positioned(
          left: 24,
          right: 24,
          bottom: 0,
          child: StreamBuilder<Duration>(
            stream: player.positionStream,
            builder: (_, snap) {
              final d = player.duration?.inMilliseconds ?? 0;
              final p = snap.data?.inMilliseconds ?? 0;
              return LinearProgressIndicator(
                  value: d > 0 ? (p / d).clamp(0.0, 1.0) : 0,
                  minHeight: 3,
                  color: const Color(0xFF7C5CD6),
                  backgroundColor: Colors.black12);
            },
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          ListView(
            padding: EdgeInsets.fromLTRB(16, 12, 16, cur == null ? 24 : 100),
            children: [header(), body()],
          ),
          if (cur != null)
            Positioned(left: 16, right: 16, bottom: 12, child: mini()),
        ]),
      ),
    );
  }
}
