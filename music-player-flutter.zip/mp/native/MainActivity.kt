package com.example.music_player

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var channel: MethodChannel? = null

    private fun viewIntent(id: Long): Intent {
        val uri = Uri.parse("content://media/external/audio/media/$id")
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "audio/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun incomingUri(i: Intent?): String? =
        if (i?.action == Intent.ACTION_VIEW) i.data?.toString() else null

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingUri(intent)?.let { channel?.invokeMethod("newIntent", it) }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "music_player/media")
        channel!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "getSongs" -> Thread {
                    val list = ArrayList<Map<String, Any?>>()
                    try {
                        val proj = arrayOf(
                            MediaStore.Audio.Media._ID,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION
                        )
                        val c = contentResolver.query(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                            MediaStore.Audio.Media.DURATION + " >= 5000", null,
                            MediaStore.Audio.Media.DATE_ADDED + " DESC"
                        )
                        c?.use {
                            while (it.moveToNext()) {
                                list.add(mapOf(
                                    "id" to it.getLong(0),
                                    "title" to it.getString(1),
                                    "artist" to it.getString(2),
                                    "album" to it.getString(3),
                                    "duration" to it.getLong(4)
                                ))
                            }
                        }
                    } catch (e: Exception) { }
                    runOnUiThread { result.success(list) }
                }.start()
                "getIntentUri" -> result.success(incomingUri(intent))
                "isDefault" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    val ri = packageManager.resolveActivity(viewIntent(id), PackageManager.MATCH_DEFAULT_ONLY)
                    result.success(ri?.activityInfo?.packageName == packageName)
                }
                "openPicker" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    try { startActivity(viewIntent(id)) } catch (e: Exception) { }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}
